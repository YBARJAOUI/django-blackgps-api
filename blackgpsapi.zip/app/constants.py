ADMIN = 1
STAFF = 2
CLIENT = 3


USER_TYPE_CHOICES = (
      (ADMIN, 'admin'),
      (STAFF, 'staff'),
      (CLIENT, 'Client'),

)


INWI = 1 
ORANGE = 2
IAM = 3
OPERATOR=(
      (INWI,'inwi'),
       (ORANGE,'orange'),
        (IAM,'iam'),
)