import json
import os
import random
import shutil
import string
import threading
from datetime import datetime
from pathlib import Path

# importation de firebase
import firebase_admin
import jwt
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from firebase_admin import credentials, firestore, initialize_app, messaging
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from blackgpsapi.settings import SECRET_KEY

from .models import *
from .serializers import *


def send_notification(device_token, title, body, image=None):
    message = messaging.Message(
            notification=messaging.Notification(
                title=title,
                body=body,
                image=image,
            ),
            token=device_token
        )
    response = messaging.send(message)
    print('Successfully sent message:', response)

class RegisterView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return({'message':'{}'.format(serializer.errors)})

class CarView(APIView):
    permission_classes=(IsAuthenticated,)

    def post(self,request):
        token = request.META.get('HTTP_AUTHORIZATION') 
        token = token.replace('Bearer ', '')
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        try:
            user = User.objects.filter(id=payload["user_id"]).first()
            data = request.data
            serializer = CarSerializer(data=data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors,status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'message':'{}'.format(e)},status=status.HTTP_400_BAD_REQUEST) 
            
    def get(self,request,pk=None):
        token = request.META.get('HTTP_AUTHORIZATION') 
        token = token.replace('Bearer ', '')
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])

        try:
            user = User.objects.filter(id=payload["user_id"]).first()
            if pk == None:
                data = Car.objects.filter(Q( user_id=user) & Q(is_deleted=False))
                serializer = CarSerializer(data, many=True)
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                data = get_object_or_404(Car,plate_number=pk,user_id=user)
                serializer = CarSerializer(data)
                return Response(serializer.data,status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'message':'{}'.format(e)},status=status.HTTP_400_BAD_REQUEST) 
    

    def put(self, request, pk):
        token = request.META.get('HTTP_AUTHORIZATION')
        token = token.replace('Bearer ', '')
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        try:
            user = User.objects.get(id=payload["user_id"])
            car = get_object_or_404(Car, plate_number=pk,user_id=user)
            if car.user_id != user:
                return Response({'message': 'you must have authorisation to modify this car'}, status=status.HTTP_403_FORBIDDEN)
            serializer = CarSerializer(car, data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_200_OK)
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'message': '{}'.format(e)}, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request, pk):
        token = request.META.get('HTTP_AUTHORIZATION')
        token = token.replace('Bearer ', '')
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        try:
            user = User.objects.get(id=payload["user_id"])
            car = get_object_or_404(Car, plate_number=pk,user_id=user)
            if car.user_id != user:
                return Response({'message': 'you must have authorisation to delete this car'}, status=status.HTTP_403_FORBIDDEN)
            car.is_deleted = True
            car.save()
            return Response({'message': 'Car successfully deleted '}, status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({'message': '{}'.format(e)}, status=status.HTTP_400_BAD_REQUEST)


class GpsDevicesView(APIView):
    permission_classes = (IsAuthenticated,)

    def post(self, request):
        serializer = GpsDevicesSerializer(data=request.data)
        if serializer.is_valid():
            gps_device = serializer.save()  # Save the device and get the instance
            # Handle device token separately if it's part of the request
            device_token = request.data.get('token')
            if device_token:
                gps_device.device_token = device_token
                gps_device.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        device = get_object_or_404(GpsDevices, imei=pk)
        serializer = GpsDevicesSerializer(device, data=request.data)
        if serializer.is_valid():
            gps_device = serializer.save()
            device_token = request.data.get('token')
            if device_token:
                gps_device.device_token = device_token
                gps_device.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request,pk=None):
       
        try:
            if pk == None:
                devices = GpsDevices.objects.filter(is_deleted=False)
                serializer = GpsDevicesSerializer(devices, many=True)
                return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                devices =  get_object_or_404(GpsDevices,imei=pk)
                serializer = GpsDevicesSerializer(devices)
                return Response(serializer.data,status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'message': '{}'.format(e)}, status=status.HTTP_400_BAD_REQUEST)

    
        

    def delete(self, request, pk):
        try:
            device = get_object_or_404(GpsDevices, imei=pk)
            device.is_deleted = True
            device.save()
            return Response({'message': 'Car successfully deleted '},status=status.HTTP_204_NO_CONTENT)
        except Exception as e:
            return Response({'message': '{}'.format(e)}, status=status.HTTP_400_BAD_REQUEST)




class DeviceTokenUpdateView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        token = request.data.get('device_token')
        if token:
            user.device_token = token
            user.save()
            return Response({'message': 'Device token updated successfully'}, status=200)
        return Response({'error': 'No token provided'}, status=400)





        
class LastTrackView(APIView):
    def get(self, request, date, pk):
        BASE_DIR = Path(__file__).resolve().parent.parent
        directory = os.path.join(BASE_DIR, 'trackers', date)
        file_path = os.path.join(directory, f"{pk}.json")

        if not os.path.exists(directory):
            return JsonResponse({'error': f'Data for GPS with date: {date} not found'}, status=404)
        
        if not os.path.exists(file_path):
            return JsonResponse({'error': f'Data for GPS with IMEI {pk} not found'}, status=404)

        try:
            with open(file_path, 'r') as json_file:
                gps_data = json.load(json_file)
                if not gps_data:
                    return JsonResponse({'error': 'Le fichier JSON est vide'}, status=404)
                return JsonResponse([gps_data[-1]], safe=False)  # Retourne le dernier élément enveloppé dans une liste
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Erreur de format dans le fichier JSON'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

#  live data for tracking realtime is from here
class LastSqlTrackView(APIView):
    def get(self, request, imei):
        try:
            # Récupérer la dernière entrée pour un IMEI spécifique
            last_entry = TrackerData.objects.filter(imei=imei).order_by('-date_created').first()
            
            if last_entry:
                response_content = [
                    last_entry.data
                ]
                return JsonResponse(response_content, safe=False,status=status.HTTP_200_OK)
            else:
                return JsonResponse({'error': 'Aucune donnée trouvée pour cet IMEI.'}, status=status.HTTP_404_NOT_FOUND)

        except Exception as e:
            return JsonResponse({'error': 'Erreur lors de la récupération des données : ' + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class SqlTrackerView(APIView):
        def get(self, request, imei):
            try:
                # Filtrer les données uniquement par IMEI
                data_entries = TrackerData.objects.filter(imei=imei)

                if not data_entries.exists():
                    return JsonResponse({'error': 'Aucune donnée trouvée pour cet IMEI.'}, status=status.HTTP_404_NOT_FOUND)

                # Préparation de la réponse
                data_list = [entry.data for entry in data_entries]     
                    
                return JsonResponse(data_list, safe=False, status=status.HTTP_200_OK)

            except Exception as e:
                return JsonResponse({'error': 'Erreur lors de la récupération des données : ' + str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# here data gps is processed for path and trajectories
class TrackerView(APIView):
    def post(self, request):
        BASE_DIR = Path(__file__).resolve().parent.parent
        try:
            imei = request.data.get('imei')
            if not GpsDevices.objects.filter(imei=imei).exists():
                raise ValueError("Aucun GPS avec l'IMEI fourni n'a été trouvé.")
            
            serializer = TrackerGpsDataSerializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
                return Response({'message': 'Données bien enregistrées'}, status=status.HTTP_200_OK)
            return JsonResponse({'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return JsonResponse({'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)
      
    def get(self,request,date,pk):
       BASE_DIR = Path(__file__).resolve().parent.parent
       directory = f"{BASE_DIR}/trackers/{date}"
       if os.path.exists(directory):
           file = f"{directory}/{pk}.json"
           if os.path.exists(file):
               with open(file, 'r') as json_file:
                   gps_data = json.load(json_file)
               return JsonResponse(gps_data,safe=False)
           else:
               return JsonResponse({'error': f'Data for GPS with IMEI {pk} not found'}, status=404)
       else:
           return JsonResponse({'error': f'Data for GPS with date : {date} not found'},status=404)



    
    
class UserView(APIView):
    permission_classes = (IsAuthenticated,)
    def get(self, request, pk=None):
        token = request.META.get('HTTP_AUTHORIZATION') 
        token = token.replace('Bearer ', '')
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        try:
            user = User.objects.filter(id=payload["user_id"]).first()
            if user.user_type !=3 :
              if pk == None:
                data = User.objects.filter(is_deleted=False)
                serializer = UserSerializer(data, many=True)
                return Response(serializer.data,status=status.HTTP_200_OK)
              else:
                  data = get_object_or_404(User,id=pk,is_deleted=False)
                  serializer = UserSerializer(data)
                  return Response(serializer.data,status=status.HTTP_200_OK)
            else:
                return Response({'message':'utilisateur non autorisé'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'message':'{}'.format(e)},status=status.HTTP_400_BAD_REQUEST) 
    
    def put(self, request, pk):
        token = request.META.get('HTTP_AUTHORIZATION') 
        token = token.replace('Bearer ', '')
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        try:
            user = User.objects.filter(id=payload["user_id"]).first()
            if user.user_type !=3 :
              user_ = get_object_or_404(User,id=pk)
              serializer = UserSerializer(user_, data=request.data)
              
              if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_200_OK)
              else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response({'message':'utilisateur non autorisé pour la modification'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'message':'{}'.format(e)},status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        token = request.META.get('HTTP_AUTHORIZATION') 
        token = token.replace('Bearer ', '')
        payload = jwt.decode(token, SECRET_KEY, algorithms=["HS256"])
        try:
            user = User.objects.filter(id=payload["user_id"]).first()
            if user.user_type == 1 :
              user_ = get_object_or_404(User,id=pk)
              user_.is_deleted=True
              user_.save()
              return Response({'message': 'utilisateur supprimé avec succès'}, status=status.HTTP_204_NO_CONTENT)
              
            else:
                return Response({'message':'utilisateur non autorisé pour la suppression'}, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({'message':'{}'.format(e)},status=status.HTTP_400_BAD_REQUEST) 
    
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)
    
    
class LogoutView(APIView):
    def post(self, request):
        response = Response()
        response.delete_cookie('csrftoken')
        response.data = {
            'message': 'success'
        }
        return response